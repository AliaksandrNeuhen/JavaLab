package com.epam.testapp.presentation.action;

import java.util.Locale;

import org.apache.struts.Globals;
import org.junit.Test;

import servletunit.struts.MockStrutsTestCase;;

public class TestNewsAction extends MockStrutsTestCase {
	static {
		System.out.println(System.getProperty("user.dir"));
	}
	@Test
	public void testChangeLanguage(){
		setRequestPathInfo("/ModuleAction.do");
		addRequestParameter("method", "changeLanguage");
		addRequestParameter("language", "ru");
		
		actionPerform();
		
		Locale expectedLocale = Locale.forLanguageTag("ru");
		Locale sessionLocale = (Locale)getSession().getAttribute(Globals.LOCALE_KEY);
		assertEquals(expectedLocale, sessionLocale);
	}
	
}
