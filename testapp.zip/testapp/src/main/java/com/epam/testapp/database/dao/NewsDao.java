package com.epam.testapp.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import com.epam.testapp.database.connection.ConnectionPool;
import com.epam.testapp.database.exception.DaoException;
import com.epam.testapp.model.News;

public class NewsDao implements INewsDao {
	private static final String LOG_TRYING_GET_LIST = "Trying to get list of news";
	private static final String LOG_GOT_LIST = "Got list of news";
	private static final String LOG_TRYING_SAVE = "Trying to save news";
	private static final String LOG_SAVED = "News have been saved";
	private static final String LOG_TRYING_REMOVE = "Trying to remove news";
	private static final String LOG_REMOVED = "News have been removed";
	private static final String LOG_TRYING_FETCH = "Trying to fetch news";
	private static final String LOG_FETCHED = "News have been fetched";
	private static final String LOG_TRYING_UPDATE = "Trying to update news";
	private static final String LOG_UPDATED = "News have been updated";
	
	private static final String FIELD_ID = "NEWS_ID";
	private static final String FIELD_TITLE = "TITLE";
	private static final String FIELD_BRIEF = "BRIEF";
	private static final String FIELD_CONTENT = "CONTENT";
	private static final String FIELD_EDITION_DATE = "EDITION_DATE";
	
	private static final String SQL_GET_NEWS = "SELECT * FROM news ORDER BY edition_date DESC";
	private static final String SQL_GET_NEWS_BY_ID = "SELECT * FROM news WHERE NEWS_ID = ?";
	private static final String SQL_SAVE_NEWS = "INSERT INTO news (title, brief, content, edition_date) "
			+ "VALUES (?, ?, ?, ?)";
	private static final String SQL_DELETE_NEWS = "DELETE FROM NEWS WHERE news_id = ?";
	private static final String SQL_UPDATE_NEWS = "UPDATE news SET title=?, brief=?, content=?, edition_date=? "
			+ "WHERE news_id = ?";
	private static final String SQL_GET_MAX_ID = "SELECT MAX(news_id) FROM news";
	
	private static final String EXC_LIST = "Can't get list of news";
	private static final String EXC_SAVE = "Can't save news";
	private static final String EXC_DELETE = "Can't delete news";
	private static final String EXC_FETCH = "Can't get news by id";
	private static final String EXC_UPDATE = "Can't update news";
	private static final String EXC_NEWS_NOT_EXIST = "There is no news with entered ID";
	
	private static final Logger log = Logger.getLogger(NewsDao.class);
	private ConnectionPool connectionPool;
	
	@Override
	public List<News> getList() throws DaoException {
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_GET_LIST);
		}
		
		Connection conn = null;
		Statement getNewsStatement = null;
		List<News> news = new LinkedList<News>();
		News currNews = null;
		try{
			conn = connectionPool.getConnection();
			getNewsStatement = conn.createStatement();
			getNewsStatement.execute(SQL_GET_NEWS);
			ResultSet newsSet = getNewsStatement.getResultSet();
			while (newsSet.next()){
				currNews = new News();
				currNews.setId(newsSet.getInt(FIELD_ID));
				currNews.setTitle(newsSet.getString(FIELD_TITLE));
				currNews.setBrief(newsSet.getString(FIELD_BRIEF));
				currNews.setContent(newsSet.getString(FIELD_CONTENT));
				currNews.setEditionDate(newsSet.getDate(FIELD_EDITION_DATE));
				news.add(currNews);
			}
		} catch (SQLException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_LIST, e);
		}
		finally{
			connectionPool.freeConnection(conn);
		}
		
		if (log.isDebugEnabled()){
			log.debug(LOG_GOT_LIST);
		}
		return news;
	}

	@Override
	public int save(News news) throws DaoException {
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_SAVE);
		}
		
		Connection conn = null;
		PreparedStatement saveNewsStatement = null;
		try{
			conn = connectionPool.getConnection();
			saveNewsStatement = conn.prepareStatement(SQL_SAVE_NEWS);
			saveNewsStatement.setString(1, news.getTitle());
			saveNewsStatement.setString(2,  news.getBrief());
			saveNewsStatement.setString(3, news.getContent());
			java.util.Date date = news.getEditionDate();
			saveNewsStatement.setDate(4, new java.sql.Date(date.getTime()));
			saveNewsStatement.execute();
		} catch (SQLException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_SAVE, e);
		} finally {
			connectionPool.freeConnection(conn);
		}
		
		int newsId = 0;
		
		Statement getIdStatement = null;
		try{
			conn = connectionPool.getConnection();
			getIdStatement = conn.createStatement();
			getIdStatement.execute(SQL_GET_MAX_ID);
			ResultSet result = getIdStatement.getResultSet();
			if (result.next()){
				newsId = result.getInt(1);
			}
		} catch (SQLException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_SAVE, e);
		} finally {
			connectionPool.freeConnection(conn);
		}
		
		if (log.isDebugEnabled()){
			log.debug(LOG_SAVED);
		}
		return newsId;
	}

	@Override
	public void remove(int[] newsToRemove) throws DaoException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_REMOVE);
		}
		
		Connection conn = null;
		PreparedStatement removeStatement = null;
		try{
			conn = connectionPool.getConnection();
			removeStatement = conn.prepareStatement(SQL_DELETE_NEWS);
			for (int currNews: newsToRemove){
				removeStatement.setInt(1, currNews);
				removeStatement.addBatch();
			}
			removeStatement.executeBatch();
		} catch (SQLException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_DELETE, e);
		} finally{
			connectionPool.freeConnection(conn);
		}
		
		if (log.isDebugEnabled()){
			log.debug(LOG_REMOVED);
		}
	}

	@Override
	public News fetchByID(int id) throws DaoException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_FETCH);
		}
		
		News news = new News();
		Connection conn = null;
		Statement getNewsByIdStatement = null;
		try{
			conn = connectionPool.getConnection();
			getNewsByIdStatement = conn.createStatement();
			String readyQuery = SQL_GET_NEWS_BY_ID.replace("?", String.valueOf(id));
			getNewsByIdStatement.execute(readyQuery);			
			ResultSet result = getNewsByIdStatement.getResultSet();
			if (result.next()){
				news.setId(id);
				news.setTitle(result.getString(FIELD_TITLE));
				news.setBrief(result.getString(FIELD_BRIEF));
				news.setContent(result.getString(FIELD_CONTENT));
				news.setEditionDate(result.getDate(FIELD_EDITION_DATE));
			} else {
				throw new DaoException(EXC_NEWS_NOT_EXIST);
			}
		} catch (SQLException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_FETCH, e);
		} finally{
			connectionPool.freeConnection(conn);
		}
		
		if (log.isDebugEnabled()){
			log.debug(LOG_FETCHED);
		}
		return news;
	}
	
	@Override
	public void update(News news) throws DaoException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_UPDATE);
		}
		
		Connection conn = null;
		PreparedStatement updateNewsStatement = null;
		try{
			conn = connectionPool.getConnection();
			updateNewsStatement = conn.prepareStatement(SQL_UPDATE_NEWS);
			updateNewsStatement.setString(1, news.getTitle());
			updateNewsStatement.setString(2, news.getBrief());
			updateNewsStatement.setString(3, news.getContent());
			java.sql.Date sqlDate = new java.sql.Date(news.getEditionDate().getTime());
			updateNewsStatement.setDate(4, sqlDate);
			updateNewsStatement.setInt(5, news.getId());
			updateNewsStatement.execute();
		} catch (SQLException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_UPDATE, e);
		} finally{
			connectionPool.freeConnection(conn);
		}
		
		if (log.isDebugEnabled()){
			log.debug(LOG_UPDATED);
		}
	}
	
	public void setConnectionPool(ConnectionPool pool){
		connectionPool = pool;
	}

}








