package com.epam.testapp.presentation.action;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.epam.testapp.database.dao.INewsDao;
import com.epam.testapp.database.exception.DaoException;
import com.epam.testapp.exception.ProjectException;
import com.epam.testapp.model.News;
import com.epam.testapp.presentation.form.NewsForm;


public class NewsAction extends DispatchAction{
	
	private static final String LANGUAGE = "language";

	//Forwards
	
	private static final String FORWARD_LIST = "news_list";
	private static final String FORWARD_VIEW = "news_view";
	private static final String FORWARD_EDIT = "news_edit";
	
	//Session attributes
	
	private static final String ATTR_EDIT_TYPE = "edit_type";
	private static final String ATTR_CURR_PAGE = "current_page";
	private static final String ATTR_PREV_PAGE = "previous_page";
	
	//Edit types for save() method
	
	private static final String EDIT_TYPE_NEW = "new";
	private static final String EDIT_TYPE_EXIST = "exist";
	
	//Exception messages
	
	private static final String EXC_LIST = "Can't get list of news";
	private static final String EXC_VIEW = "Can't get news";
	private static final String EXC_DELETE = "Can't delete news";
	private static final String EXC_SAVE_NEW = "Can't add news";
	private static final String EXC_SAVE_EXIST = "Can't update news";
	
	///Log messages
	
	private static final String LOG_TRYING_CHANGE_LANG = "Trying to change language";
	private static final String LOG_LANG_CHANGED = "Language has been changed to";
	private static final String LOG_TRYING_LIST = "Trying to show list of news";
	private static final String LOG_GOT_LIST = "List of news has been shown";
	private static final String LOG_TRYING_VIEW = "Trying to show news";
	private static final String LOG_GOT_VIEW = "id News has been shown";
	private static final String LOG_TRYING_DELETE = "Trying to delete News";
	private static final String LOG_DELETED = "id News has been deleted";
	private static final String LOG_TRYING_SAVE = "Trying to save news";
	private static final String LOG_EDIT_TYPE_EXIST = "Editing existing news";
	private static final String LOG_EDIT_TYPE_NEW = "Creating new news";
	private static final String LOG_SAVED = "News has been saved";
	private static final String LOG_TRYING_EDIT = "Trying to show edit page";
	private static final String LOG_GOT_EDIT = "Edit page has been shown";
	private static final String LOG_TRYING_CANCEL = "Trying to cancel editing";
	private static final String LOG_CANCELED = "Editing news has been canceled";
	
	
	private static final Logger log = Logger.getLogger(NewsAction.class);
	private INewsDao dao;
	
	public void setDao(INewsDao newDao){
		dao = newDao;
	}
	public INewsDao getDao(){
		return dao;
	}
	
	/**
	 * Changes language according to session attribute "language"
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward changeLanguage(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_CHANGE_LANG);
		}
		
		HttpSession session = request.getSession();
		
		//getting current page from session
		String currPage = (String)session.getAttribute(ATTR_CURR_PAGE);

		String language = request.getParameter(LANGUAGE);
		request.getSession().setAttribute(Globals.LOCALE_KEY, Locale.forLanguageTag(language));
		
		if (log.isDebugEnabled()){
			log.debug(LOG_LANG_CHANGED + language);
		}
		return actionMapping.findForward(currPage);
	}
	
	/**
	 * Method for displaying NewsList page
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws ProjectException
	 */
	
	public ActionForward list(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws ProjectException {
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_LIST);
		}
		
		NewsForm form = (NewsForm)actionForm;
		try{
			form.setNewsList(dao.getList());	
		} catch (DaoException e){
			log.error(e.getMessage(), e);
			throw new ProjectException(EXC_LIST, e);
		}
		
		HttpSession session = request.getSession();
		session.setAttribute(ATTR_PREV_PAGE, session.getAttribute(ATTR_CURR_PAGE));
		session.setAttribute(ATTR_CURR_PAGE, FORWARD_LIST);
		
		if (log.isDebugEnabled()){
			log.debug(LOG_GOT_LIST);
		}
		return actionMapping.findForward(FORWARD_LIST);
	}
	
	/**
	 * Method for displaying NewsView page
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws ProjectException
	 */
	
	public ActionForward view(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws ProjectException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_VIEW);
		}
		
		int id = 0;
		NewsForm form = (NewsForm)actionForm;
		try{
			id = Integer.valueOf(request.getParameter("id"));
			form.setNewsMessage(dao.fetchByID(id));
		} catch (DaoException e){
			log.error(e.getMessage(), e);
			throw new ProjectException(EXC_VIEW, e);
		}
		
		HttpSession session = request.getSession();
		session.setAttribute(ATTR_PREV_PAGE, session.getAttribute(ATTR_CURR_PAGE));
		session.setAttribute(ATTR_CURR_PAGE, FORWARD_VIEW);
		
		if (log.isDebugEnabled()){
			log.debug(id + LOG_GOT_VIEW);
		}
		return actionMapping.findForward(FORWARD_VIEW);
	}
	
	/**
	 * Method for deleting news from list
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws ProjectException
	 */
	
	public ActionForward delete(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws ProjectException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_DELETE);
		}
		
		NewsForm form = (NewsForm)actionForm;
		int [] newsToDelete = null;
		try{
			// if array of IDs int the form is not null, 
			// then delete news with ID from array
			// else delete news in NewsMessage
			if (form.getNewsToDelete() != null){
				newsToDelete = form.getNewsToDelete();
			} else{
				newsToDelete = new int[1];
				newsToDelete[0] = Integer.valueOf(request.getParameter("id"));
			}
			dao.remove(newsToDelete);				
			
			form.setNewsList(dao.getList());
			
			// reset array of IDs
			int [] newArray = null;
			form.setNewsToDelete(newArray);
		} catch (DaoException e){
			log.error(e.getMessage(), e);
			throw new ProjectException(EXC_DELETE, e);
		}
		
		HttpSession session = request.getSession();
		session.setAttribute(ATTR_PREV_PAGE, session.getAttribute(ATTR_CURR_PAGE));
		session.setAttribute(ATTR_CURR_PAGE, FORWARD_LIST);
		
		if (log.isDebugEnabled()){
			log.debug(newsToDelete + LOG_DELETED);
		}
		return actionMapping.findForward(FORWARD_LIST);
	}
	
	/**
	 * Method for saving or adding news
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws ProjectException
	 */
	
	public ActionForward save(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws ProjectException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_SAVE);
		}
		
		NewsForm form = (NewsForm)actionForm;
		HttpSession session = request.getSession();
		int newsId = 0;
		
		// if news exists
		if (EDIT_TYPE_EXIST.equals(session.getAttribute(ATTR_EDIT_TYPE))){
			if (log.isDebugEnabled()){
				log.debug(LOG_EDIT_TYPE_EXIST);
			}
			try{
				dao.update(form.getNewsMessage());
			} catch (DaoException e){
				log.error(e.getMessage(), e);
				throw new ProjectException(EXC_SAVE_EXIST, e);
			}
			
		// if news doesn't exist
		} else {
			if (log.isDebugEnabled()){
				log.debug(LOG_EDIT_TYPE_NEW);
			}
			try{
				newsId = dao.save(form.getNewsMessage());
				form.getNewsMessage().setId(newsId);
			} catch (DaoException e){
				log.error(e.getMessage(), e);
				throw new ProjectException(EXC_SAVE_NEW, e);
			}
		}
		
		try {
			form.setNewsList(dao.getList());
		} catch (DaoException e) {
			log.error(e.getMessage(), e);
			throw new ProjectException(EXC_LIST, e);
		}
		
		session.setAttribute(ATTR_PREV_PAGE, session.getAttribute(ATTR_CURR_PAGE));
		session.setAttribute(ATTR_CURR_PAGE, FORWARD_LIST);
		
		if (log.isDebugEnabled()){
			log.debug(LOG_SAVED);
		}
		return actionMapping.findForward(FORWARD_VIEW);
	}
	
	/**
	 * Method for showing NewsEdit page for editing existing news
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws ProjectException
	 */
	public ActionForward edit(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws ProjectException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_EDIT);
		}
		
		NewsForm form = (NewsForm)actionForm;
		
		try{
			int id = Integer.valueOf(request.getParameter("id"));
			form.setNewsMessage(dao.fetchByID(id));
		} catch (DaoException e){
			log.error(e.getMessage(), e);
			throw new ProjectException(EXC_VIEW, e);
		}
		
		HttpSession session = request.getSession();
		session.setAttribute(ATTR_PREV_PAGE, session.getAttribute(ATTR_CURR_PAGE));
		session.setAttribute(ATTR_EDIT_TYPE, EDIT_TYPE_EXIST);
		session.setAttribute(ATTR_CURR_PAGE, FORWARD_EDIT);
		
		if (log.isDebugEnabled()){
			log.debug(LOG_GOT_EDIT);
		}
		return actionMapping.findForward(FORWARD_EDIT);
	}
	
	/**
	 * Method for showing NewsEdit page for adding news
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	
	public ActionForward add(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response){
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_EDIT);
		}
		
		NewsForm form = (NewsForm)actionForm;
		
		form.setNewsMessage(new News());
		
		HttpSession session = request.getSession();
		session.setAttribute(ATTR_PREV_PAGE, session.getAttribute(ATTR_CURR_PAGE));
		session.setAttribute(ATTR_CURR_PAGE, FORWARD_EDIT);
		session.setAttribute(ATTR_EDIT_TYPE, EDIT_TYPE_NEW);
		
		if (log.isDebugEnabled()){
			log.debug(LOG_GOT_EDIT);
		}
		return actionMapping.findForward(FORWARD_EDIT);
	}
	
	/**
	 * Method for cancelling editing news
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	
	public ActionForward cancel(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response){
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_CANCEL);
		}
		
		HttpSession session = request.getSession();
		String prevPage = (String)session.getAttribute(ATTR_PREV_PAGE);
		String currPage = (String)session.getAttribute(ATTR_CURR_PAGE);
		session.setAttribute(ATTR_CURR_PAGE, prevPage);
		session.setAttribute(ATTR_PREV_PAGE, currPage);
		
		if (log.isDebugEnabled()){
			log.debug(LOG_CANCELED);
		}
		return actionMapping.findForward(prevPage);
	}
}