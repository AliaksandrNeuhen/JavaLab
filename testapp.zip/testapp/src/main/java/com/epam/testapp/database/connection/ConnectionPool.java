package com.epam.testapp.database.connection;

import java.util.Properties;
import java.util.concurrent.LinkedBlockingQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.epam.testapp.database.exception.DaoException;

/**
 * Connection pool realization.
 * @author Aliaksandr_Neuhen
 *
 */
public class ConnectionPool {
	private static final String LOG_CP_CREATING = "Creating connection pool";
	private static final String LOG_DRIVER_LOADING = "Loading JDBC driver";
	private static final String LOG_CREATING_QUEUES = "Creating connections queues";
	private static final String LOG_FILLING_QUEUE = "Filling connections queue";
	private static final String LOG_GETTING_CONN = "Trying to get connection";
	private static final String LOG_GOT_CONN = "Got connection";
	private static final String LOG_TRYING_FREE_CONN = "Trying to free connection";
	private static final String LOG_FRIED_CONN = "Connection has been returned to pool";
	private static final String LOG_TRYING_CLOSE_CONN = "Trying to close connections";
	private static final String LOG_CONN_CLOSED = "Connections have been closed";
	
	private static final String EXC_DRIVER_NOT_FOUND = "Driver not found";
	private static final String EXC_INT = "Interrupted";
	private static final String EXC_CREATE = "Can't create connection";
	private static final String EXC_CLOSE = "Cannot close connection";
	
	
	private static final String USERNAME = "user";
	private static final String PASSWORD = "password";
	private static final String CHARACTER_ENCODING = "characterEncoding";
	private static final String USE_UNICODE = "useUnicode";
	
	private static final Logger log = Logger.getLogger(ConnectionPool.class);
	
	private LinkedBlockingQueue<Connection> freeConnections;
	private LinkedBlockingQueue<Connection> usedConnections;
	
	private static ConnectionPool instance;
	
	/**
	 * Gets an instance of ConnectionPool
	 * @return current instance of ConnectionPool
	 * @throws DaoException
	 */
	public synchronized static ConnectionPool getInstance() throws DaoException{
		return instance;
	}
	
	public static void setInstance(ConnectionPool instance) {
		ConnectionPool.instance = instance;
	}
	
	public ConnectionPool(String username, String password, String url, int capacity, String driver, 
			String encoding, String useUnicode) throws DaoException{
		if (log.isDebugEnabled()){
			log.debug(LOG_CP_CREATING);
		}
		
		Properties properties = new Properties();
		properties.put(USERNAME, username);
		properties.put(PASSWORD, password);
		properties.put(CHARACTER_ENCODING, encoding);
		properties.put(USE_UNICODE, useUnicode);
		try{
			if (log.isDebugEnabled()){
				log.debug(LOG_DRIVER_LOADING);
			}
			Class.forName(driver);
		} catch (ClassNotFoundException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_DRIVER_NOT_FOUND, e);
		}
		if (log.isDebugEnabled()){
			log.debug(LOG_CREATING_QUEUES);
		}
		freeConnections = new LinkedBlockingQueue<Connection>(capacity);
		usedConnections = new LinkedBlockingQueue<Connection>(capacity);
		
		if (log.isDebugEnabled()){
			log.debug(LOG_FILLING_QUEUE);
		}
		for (int i = 0; i < capacity; i++){
			try {
				freeConnections.put(DriverManager.getConnection(url, properties));
			} catch (InterruptedException e){
				log.error(e.getMessage(), e);
				throw new DaoException(EXC_INT, e);
			} catch (SQLException e){
				log.error(e.getMessage(), e);
				throw new DaoException(EXC_CREATE, e);
			}
		}
	}
	
	/**
	 * Gets opened connection from pool.
	 * If pool is empty, thread is blocked while some connection will be free.
	 * @return Opened connection.
	 * @throws DaoException if thread is interrupted
	 */
	public Connection getConnection() throws DaoException{
		if (log.isDebugEnabled()){
			log.debug(LOG_GETTING_CONN);
		}
		Connection connection = null;
		try{
			connection = freeConnections.take();
			usedConnections.put(connection);
		} catch (InterruptedException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_INT, e);
		}
		
		if (log.isDebugEnabled()){
			log.debug(LOG_GOT_CONN);
		}
		return connection;
	}
	
	/**
	 * Returns connection back to the pool
	 * @param connection current connection
	 * @throws DaoException if thread is interrupted.
	 */
	public void freeConnection(Connection connection) throws DaoException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_FREE_CONN);
		}
		
		try {
			if (connection != null){
				freeConnections.put(usedConnections.take());
			}
		} catch (InterruptedException e) {
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_INT, e);
		}
		if (log.isDebugEnabled()){
			log.debug(LOG_FRIED_CONN);
		}
	}
	
	/**
	 * Gets count of free connections.
	 * @return count of free connections.
	 */
	public int getFreeConnectionsCount(){
		return freeConnections.size();
	}
	
	/**
	 * Closes all connections.
	 * @throws DaoException if thread is interrupted
	 */
	public void closeConnections() throws DaoException{
		if (log.isDebugEnabled()){
			log.debug(LOG_TRYING_CLOSE_CONN);
		}
		
		try{
			while (!freeConnections.isEmpty()){
				freeConnections.take().close();
			}
			while (!usedConnections.isEmpty()){
				usedConnections.take().close();
			}
		} catch (InterruptedException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_INT, e);
		} catch (SQLException e){
			log.error(e.getMessage(), e);
			throw new DaoException(EXC_CLOSE, e);
		}
		
		if (log.isDebugEnabled()){
			log.debug(LOG_CONN_CLOSED);
		}
	}
}
