package com.epam.testapp.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ExceptionHandler;
import org.apache.struts.config.ExceptionConfig;

public class CustomExceptionHandler extends ExceptionHandler {

	private static final Logger log = Logger.getLogger(CustomExceptionHandler.class);
	
	private static final String FORWARD_ERROR = "error";
	
	@Override
	public ActionForward execute(Exception ex, ExceptionConfig ae,
			ActionMapping actionMapping, ActionForm actionForm,
			HttpServletRequest request, HttpServletResponse response){
		
		log.error(ex.getMessage(), ex);
		return actionMapping.findForward(FORWARD_ERROR);
	}
	
}
