package com.epam.testapp.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Filter for setting request and response encoding to UTF-8
 * @author Aliaksandr_Neuhen
 *
 */

public class EncodingFilter implements Filter {
	private static final String ENCODING = "UTF-8";
	private static final String CONTENT_TYPE = "text/html;charset=UTF-8";
	
	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain next) throws IOException, ServletException {
		request.setCharacterEncoding(ENCODING);
		response.setCharacterEncoding(ENCODING);
		response.setContentType(CONTENT_TYPE);
		next.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

}
