package com.epam.testapp.database.exception;

/**
 * 
 * Exception thrown when there are some troubles with DAO
 */

public class DaoException extends Exception {
	private static final long serialVersionUID = 1L;

	public DaoException(String msg){
		super(msg);
	}

	public DaoException(String msg, Exception e){
		super(msg, e);
	}
}
