	function checkDelete(form){
		var totalCount = form.elements.length;
		var countUnchecked = 0;
		for (var i = 0; i < totalCount; i++){
			if (!form.elements[i].checked){
				countUnchecked = countUnchecked + 1;
			}
		}
		if (countUnchecked === totalCount){
			alert(chooseNewsAlert);
			return false;
		} else {
			if (confirm(confirmDeleteCheckedAlert)){
				return true;
			} else {
				return false;
			}
		}
	}
	
	function checkDeleteSingle(form){
		if (confirm(confirmDeleteSingleAlert)){
			return true;
		} else {
			return false;
		}
	}
	
	function validateNews(form){
		var title = document.getElementById("textedittitle");
		var date = document.getElementById("texteditdate");
		var brief = document.getElementById("textareaeditbrief");
		var content = document.getElementById("textareaeditcontent");
		var result = true;
		if (title.value.length === 0 || brief.value.length === 0 || content.value.length === 0){
			alert(fillFieldsAlert);
			result = false;
		}
		if (title.value.length > 100){
			alert(titleLongAlert);
			result = false;
		}
		if (brief.value.length > 500){
			alert(briefLongAlert);
			result = false;
		}
		if (content.value.length > 2048){
			alert(contentLongAlert);
			result = false;
		}
		var dateFormat = /^(\d\d)\/(\d\d)\/(\d\d\d\d)$/;
		if (!dateFormat.test(date.value)){
			alert(wrongDateAlert);
			result = false;
		} else {
			var month = date.value.split("/")[0];
			var day = date.value.split("/")[1];
			var year = date.value.split("/")[2];
			correctDate = new Date(year, month - 1, day);
			if ((correctDate.getMonth() + 1 != month) || (correctDate.getDate() != day) || (correctDate.getFullYear() != year)){
				alert(wrongDateAlert);
				result = false;
			}
		}
		return result;
	}
	
	function formatDate(form){
		var date = document.getElementById("texteditdate");
		if (date.length === 2){
			date+= "/";
		}
	}