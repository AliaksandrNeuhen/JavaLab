@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.testapp.epam.com/")
package com.epam.testapp.service;
